# German to English JSON Dictionary

This is a JSON representation of **Mr. Honey's Beginner's Dictionary (German-English)** by *Winfried Honig*. The dictionary is available in various other formats on [Project Gutenberg](http://www.gutenberg.org/ebooks/3212).

You will also find the Ruby program used to convert the HTML ebook to JSON in this repository.
